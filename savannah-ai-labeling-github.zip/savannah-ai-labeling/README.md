# Savannah AI Labeling Website

A responsive, single-page website. The HTML, internal CSS and JavaScript are all in `index.html`.

## Publish free with GitHub Pages
1. Upload `index.html` to the root of your GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Choose branch `main` and folder `/(root)`, then click **Save**.
5. Wait for GitHub Pages to show the published URL.

## Important notes
- The sample-work sections are illustrative workflows, not completed client projects.
- Image spaces are placeholders. Add approved images later under `assets/images/`.
- The header currently uses a lettermark placeholder. Add the official logo later under `assets/logo/`.
- The client and annotator forms are demonstration forms only. They do not send submissions anywhere until connected to a form service. Do not collect real applications until configured.
- No paid domain or hosting is required for GitHub Pages on a public repository.
